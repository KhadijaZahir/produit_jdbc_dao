module ma.youcode {
    requires javafx.controls;
    requires javafx.graphics;
    requires javafx.base;
    requires java.sql;
    requires commons.dbcp2;
    requires javafx.fxml;
   requires java.management;


}